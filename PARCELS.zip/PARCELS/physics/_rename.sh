#!/bin/bash

for file in physicsparcel_*.nii.gz; do
    # Extract region name (after "physicsparcel_")
    region=$(echo "$file" | sed 's/physicsparcel_//' | sed 's/.nii.gz//')

    # Final name
    newname="${region}.nii.gz"

    # Rename
    mv "$file" "$newname"
    echo "Renamed $file -> $newname"
done

