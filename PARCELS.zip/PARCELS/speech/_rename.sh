#!/bin/bash

old="speech_LH_1_5_mirrored_conjunction_final.nii"
new="speech.nii"

if [[ -f "$old" ]]; then
    mv "$old" "$new"
    echo "Renamed $old -> $new"
else
    echo "File not found: $old"
fi
