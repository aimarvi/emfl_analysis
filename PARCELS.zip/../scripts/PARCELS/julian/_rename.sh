#!/bin/bash

# Loop through all .nii.gz files in the current directory
for file in *.nii.gz; do
    # Strip the hemisphere (first character) and region (rest of filename before extension)
    hemi_char=${file:0:1}
    region_ext=${file:1}

    # Convert hemisphere to full name
    if [[ $hemi_char == "l" ]]; then
        hemi="lh"
    elif [[ $hemi_char == "r" ]]; then
        hemi="rh"
    else
        echo "Skipping $file: unknown hemisphere"
        continue
    fi

    # Strip extension to get region
    region="${region_ext%.nii.gz}"

    # Lowercase the region
    region_lower=$(echo "$region" | tr '[:upper:]' '[:lower:]')

    # Construct new filename
    newname="${hemi}.${region_lower}.nii.gz"

    # Rename the file
    mv "$file" "$newname"
    echo "Renamed $file -> $newname"
done
