#!/bin/bash

for file in *.allloc.group_constrained_800.*.nii.gz; do
    # Extract region and hemi
    region=$(echo "$file" | cut -d'.' -f1)
    hemi=$(echo "$file" | rev | cut -d'.' -f3 | rev)

    # Lowercase region and normalize
    region_lc=$(echo "$region" | tr '[:upper:]' '[:lower:]')

    # Final name
    newname="${hemi}.${region_lc}.nii.gz"

    mv "$file" "$newname"
    echo "Renamed $file -> $newname"
done

