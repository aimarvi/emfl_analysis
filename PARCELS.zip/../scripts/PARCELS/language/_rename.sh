#!/bin/bash

# Declare associative array for labels
declare -A labels=(
    [1]="lh.ifgorb"
    [2]="lh.ifg"
    [3]="lh.mfg"
    [4]="lh.anttemp"
    [5]="lh.posttemp"
    [6]="lh.ag"
    [7]="rh.ifgorb"
    [8]="rh.ifg"
    [9]="rh.mfg"
    [10]="rh.anttemp"
    [11]="rh.posttemp"
    [12]="rh.ag"
)

# Loop over langparcel_*.nii files
for file in langparcel_*.nii; do
    # Extract number from filename
    num=$(echo "$file" | grep -oP '\d+')

    # Lookup label
    label=${labels[$num]}

    if [[ -n $label ]]; then
        newname="${label}.nii"
        mv "$file" "$newname"
        echo "Renamed $file -> $newname"
    else
        echo "Skipping $file: no label found for number $num"
    fi
done
