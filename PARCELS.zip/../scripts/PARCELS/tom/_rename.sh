#!/bin/bash

for file in *_xyz.nii.gz; do
    base=$(basename "$file" _xyz.nii.gz)

    firstchar=${base:0:1}
    rest=${base:1}

    # Determine hemisphere prefix
    if [[ $firstchar == "R" ]]; then
        hemi="rh"
        region=$(echo "$rest" | tr '[:upper:]' '[:lower:]')
        newname="${hemi}.${region}.nii.gz"
    elif [[ $firstchar == "L" ]]; then
        hemi="lh"
        region=$(echo "$rest" | tr '[:upper:]' '[:lower:]')
        newname="${hemi}.${region}.nii.gz"
    else
        region=$(echo "$base" | tr '[:upper:]' '[:lower:]')
        newname="${region}.nii.gz"
    fi

    mv "$file" "$newname"
    echo "Renamed $file -> $newname"
done

