#!/bin/bash

for file in *MD*.nii.gz; do
    # Strip extension and MD ID
    base=$(basename "$file" .nii.gz)
    name_without_md=$(echo "$base" | sed 's/_MD[0-9]\{2\}$//')

    # Get hemisphere and region
    hemi_char=${name_without_md:0:1}
    region=${name_without_md:1}

    if [[ $hemi_char == "l" ]]; then
        hemi="lh"
    elif [[ $hemi_char == "r" ]]; then
        hemi="rh"
    else
        echo "Skipping $file: unknown hemisphere"
        continue
    fi

    # Normalize region name (lowercase, replace uppercase in middle)
    region_clean=$(echo "$region" | tr '[:upper:]' '[:lower:]')

    # Replace multiple underscores with single if any (just to be safe)
    region_clean=$(echo "$region_clean" | sed 's/__*/_/g')

    # Final filename
    newname="${hemi}.${region_clean}.nii.gz"

    # Rename
    mv "$file" "$newname"
    echo "Renamed $file -> $newname"
done

